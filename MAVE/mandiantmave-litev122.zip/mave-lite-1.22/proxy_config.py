ENABLE_PROXY = 'n'
HOST = '127.0.0.1'
PORT = 8080
PROXY_USR = "proxy_usr"
PROXY_PASS = "proxy_pass"
NEED_PASS = 'n'
