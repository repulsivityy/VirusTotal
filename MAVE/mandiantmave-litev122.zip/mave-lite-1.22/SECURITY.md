# Security Policy

## Supported Versions

Supported versions will be in accordance with the included license.txt file.

## Reporting a Vulnerability

Please report issues including vulnerabilities with the example code using mandiant-intel-tech-accelerations [at] google.com.
